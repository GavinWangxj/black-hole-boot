package cn.cincout.tech.springmybatisjmsjta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMybatisJmsJtaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMybatisJmsJtaApplication.class, args);
	}
}
